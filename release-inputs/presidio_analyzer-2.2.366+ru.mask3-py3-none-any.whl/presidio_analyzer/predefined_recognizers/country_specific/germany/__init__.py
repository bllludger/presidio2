"""Germany-specific recognizers package."""
